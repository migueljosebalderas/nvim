package lint

func baz() {}
